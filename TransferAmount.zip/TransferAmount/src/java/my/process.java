
package my;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.*;
import java.util.Date;

public class process extends HttpServlet {

    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        try  {
            String ac1,ac2,gc,gc1,gc2,gc3;
int amount;

//get the value that is enter by user.

ac1=request.getParameter("sender");
ac2=request.getParameter("recive");

amount=Integer.parseInt(request.getParameter("amt"));

gc1=request.getParameter("first");
gc2=request.getParameter("second");
gc3=request.getParameter("third");
gc=gc1+""+gc2+""+gc3;
String trType="Saving";
//genrate random

  String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
   
    StringBuilder salt = new StringBuilder();
  
      Random rnd = new Random();
     
   while (salt.length() < 18) { 

            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
 
           salt.append(SALTCHARS.charAt(index));
      
  }
      
  String saltStr = salt.toString();
   Class.forName("org.apache.derby.jdbc.ClientDriver");
Connection cn;
cn=DriverManager.getConnection("jdbc:derby://localhost:1527/banking;user=niit;password=12345;");
PreparedStatement pst,pst1;
Date d=new Date();
pst=cn.prepareStatement("insert into Transactions values('"+saltStr+"','"+trType
+"','"+ac1+"','"+ac2+"','"+d.toString()+"')");
int xx=pst.executeUpdate();
pst1=cn.prepareStatement("insert into Account values('"+ac1+"',"+amount+",'"+gc+"')");
int yy=pst1.executeUpdate();
if(xx==1 && yy==1)
{
out.println("Amount Transfer Successfully.......");
}
else
{
out.println("Try Again .......");
}
        }
catch(Exception ex)
{
out.println(ex);
}
    }

    
}
